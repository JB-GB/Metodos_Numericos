#!/bin/bash
echo "========================================"
echo "PharmaKin - Inicio Rapido"
echo "========================================"
echo ""
echo "Iniciando aplicacion con Docker..."
echo ""
docker-compose up --build

