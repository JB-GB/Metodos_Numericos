#!/bin/bash
echo "Iniciando PharmaKin Backend..."
cd backend
python3 app.py

